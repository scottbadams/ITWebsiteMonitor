using System.Globalization;
using System.Reflection;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using WebsiteMonitor.App.Infrastructure;
using WebsiteMonitor.Storage.Data;

namespace WebsiteMonitor.App.Snapshots;

public sealed class HtmlSnapshotHostedService : BackgroundService
{
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ProductPaths _paths;
    private readonly SnapshotOptions _opt;
    private readonly ILogger<HtmlSnapshotHostedService> _logger;

    public HtmlSnapshotHostedService(
        IServiceScopeFactory scopeFactory,
        ProductPaths paths,
        IOptions<SnapshotOptions> opt,
        ILogger<HtmlSnapshotHostedService> logger)
    {
        _scopeFactory = scopeFactory;
        _paths = paths;
        _opt = opt.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        var tick = TimeSpan.FromSeconds(Math.Max(5, _opt.TickSeconds));
        using var timer = new PeriodicTimer(tick);

        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                await WriteAllSnapshotsAsync(stoppingToken);
            }
            catch (OperationCanceledException)
            {
                // normal shutdown
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Snapshot tick failed.");
            }
        }
    }

    private async Task WriteAllSnapshotsAsync(CancellationToken ct)
    {
        using var scope = _scopeFactory.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<WebsiteMonitorDbContext>();

        var instances = await db.Instances
            .AsNoTracking()
            .Where(i => i.Enabled && i.WriteHtmlSnapshot && i.OutputFolder != null && i.OutputFolder != "")
            .ToListAsync(ct);

        foreach (var inst in instances)
        {
            try
            {
                await WriteOneInstanceSnapshotAsync(
                    db,
                    inst.InstanceId,
                    inst.DisplayName,
                    inst.TimeZoneId,
                    inst.OutputFolder!,
                    IsInstancePaused(inst, DateTime.UtcNow),
                    ct);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Snapshot write failed. Instance={InstanceId}", inst.InstanceId);
            }
        }
    }

    private async Task WriteOneInstanceSnapshotAsync(
        WebsiteMonitorDbContext db,
        string instanceId,
        string displayName,
        string? timeZoneId,
        string outputFolderRaw,
        bool instancePaused,
        CancellationToken ct)
    {
        // Relative -> under DataRoot. Absolute -> use as-is.
        var outputFolder = Path.IsPathRooted(outputFolderRaw)
            ? outputFolderRaw
            : Path.Combine(_paths.DataRoot, outputFolderRaw);

        Directory.CreateDirectory(outputFolder);

        // Per-target snapshots live under {outputFolder}\targets\{TargetId}.html
        var targetsFolder = Path.Combine(outputFolder, "targets");
        Directory.CreateDirectory(targetsFolder);

        var tz = ResolveTimeZone(timeZoneId, _logger);
        var tzLabel = string.IsNullOrWhiteSpace(timeZoneId) ? TimeZoneInfo.Local.Id : timeZoneId!.Trim();

        var targets = await db.Targets
            .AsNoTracking()
            .Where(t => t.InstanceId == instanceId && t.Enabled)
            .OrderBy(t => t.Url)
            .ToListAsync(ct);

        if (targets.Count == 0)
            return;

        var targetIds = targets.Select(t => t.TargetId).ToList();

        var states = await db.States
            .AsNoTracking()
            .Where(s => targetIds.Contains(s.TargetId))
            .ToDictionaryAsync(s => s.TargetId, ct);

        // Pull a bounded set of recent checks across all targets, then group in-memory.
        var perTargetN = Math.Max(1, _opt.HistoryCount);
        var maxChecks = perTargetN * targets.Count;

        var recentChecks = await db.Checks
            .AsNoTracking()
            .Where(c => targetIds.Contains(c.TargetId))
            .OrderByDescending(c => c.TimestampUtc)
            .Take(maxChecks)
            .ToListAsync(ct);

        var recentByTarget = recentChecks
            .GroupBy(c => c.TargetId)
            .ToDictionary(g => g.Key, g => g.Take(perTargetN).ToList());

        // “Last Run” (snapshot context): latest check timestamp we included
        DateTime? lastRunUtc = recentChecks.Count == 0 ? null : recentChecks.Max(c => c.TimestampUtc);

        var nowUtc = DateTime.UtcNow;

        // -------------------------
        // Write per-instance snapshot
        // -------------------------
        var sb = new StringBuilder();
        sb.AppendLine("<!doctype html>");
        sb.AppendLine("<html><head><meta charset=\"utf-8\"/>");
        sb.AppendLine($"<title>WebsiteMonitor - {Html(displayName)} ({Html(instanceId)})</title>");
        sb.AppendLine("<style>");
        sb.AppendLine("body{font-family:Calibri,Segoe UI,Arial,sans-serif;margin:16px;background:#111;color:#eee;}");
        sb.AppendLine("h1{margin:0 0 6px 0;font-size:20px;}");
        sb.AppendLine(".meta{color:#bbb;margin:0 0 12px 0;font-size:12px;}");
        sb.AppendLine("table{border-collapse:collapse;width:100%;}");
        sb.AppendLine("th,td{border:1px solid #333;padding:8px;vertical-align:top;}");
        sb.AppendLine("th{background:#1b1b1b;text-align:left;}");
        sb.AppendLine(".up{background:#0f2a16;}");
        sb.AppendLine(".down{background:#2a0f0f;}");
        sb.AppendLine(".unknown{background:#1a1a1a;}");
        sb.AppendLine(".degraded{background:#2a250f;}");
        sb.AppendLine(".paused{background:#2a2600;}");
        sb.AppendLine(".url2{color:#aaa;font-size:12px;margin-top:4px;}");
        sb.AppendLine(".site1 a{color:inherit;text-decoration:none;}");
        sb.AppendLine(".site1 a:hover{text-decoration:underline;}");
        sb.AppendLine(".hist{margin-top:6px;font-size:12px;color:#ddd;}");
        sb.AppendLine(".hist table{width:100%;}");
        sb.AppendLine(".hist th,.hist td{padding:4px 6px;}");
        sb.AppendLine("</style></head><body>");

        sb.AppendLine($"<h1>WebsiteMonitor - {Html(displayName)} ({Html(instanceId)})</h1>");
        sb.Append("<div class=\"meta\">");
        sb.Append($"Generated ({Html(tzLabel)}): {Html(FmtLocal(nowUtc, tz))}");
        if (lastRunUtc != null)
            sb.Append($" &nbsp;|&nbsp; Last Run ({Html(tzLabel)}): {Html(FmtLocal(lastRunUtc.Value, tz))}");
        if (instancePaused)
            sb.Append(" &nbsp;|&nbsp; PAUSED");
        sb.AppendLine("</div>");

        sb.AppendLine("<table>");
        sb.AppendLine("<thead><tr>");
        sb.AppendLine($"<th>Site</th><th>State</th><th>Since ({Html(tzLabel)})</th><th>Last Check ({Html(tzLabel)})</th><th>Last Summary</th>");
        sb.AppendLine("</tr></thead><tbody>");

        foreach (var t in targets)
        {
            states.TryGetValue(t.TargetId, out var st);

            recentByTarget.TryGetValue(t.TargetId, out var histList);
            var latestChk = (histList != null && histList.Count > 0) ? histList[0] : null;

            var stateText = "Unknown";
            var css = "unknown";

            DateTime? sinceUtc = null;
            DateTime? lastCheckUtc = null;
            var lastSummary = "";

            if (st != null)
            {
                // Same degraded rule as monitor page:
                var degraded = st.IsUp && st.LoginDetectedEver && !st.LoginDetectedLast;

                stateText = st.IsUp ? (degraded ? "Degraded" : "Up") : "Down";
                css = st.IsUp ? (degraded ? "degraded" : "up") : "down";

                sinceUtc = st.StateSinceUtc;
                lastCheckUtc = st.LastCheckUtc;
                lastSummary = st.LastSummary ?? "";
            }
            else if (latestChk != null)
            {
                // Fallback if state row doesn’t exist yet
                lastCheckUtc = latestChk.TimestampUtc;
                lastSummary = latestChk.Summary ?? "";
            }

            if (instancePaused)
            {
                stateText = "Paused";
                css = "paused";
            }

            var finalUrl = (st?.LastFinalUrl ?? latestChk?.FinalUrl ?? "").Trim();

            // In the per-instance snapshot: Site (line 1) links to the per-target snapshot file
            var perTargetRel = $"targets/{t.TargetId}.html";

            sb.AppendLine($"<tr class=\"{css}\">");
            sb.AppendLine("<td>");
            sb.AppendLine($"<div class=\"site1\"><a href=\"{HtmlAttr(perTargetRel)}\">{Html(t.Url)}</a></div>");
            sb.AppendLine($"<div class=\"url2\">{Html(finalUrl)}</div>");
            sb.AppendLine("</td>");

            sb.AppendLine($"<td>{Html(stateText)}</td>");
            sb.AppendLine($"<td>{(sinceUtc == null ? "" : Html(FmtLocal(sinceUtc.Value, tz)))}</td>");
            sb.AppendLine($"<td>{(lastCheckUtc == null ? "" : Html(FmtLocal(lastCheckUtc.Value, tz)))}</td>");
            sb.AppendLine($"<td>{Html(lastSummary)}</td>");
            sb.AppendLine("</tr>");

            // Also (re)write the per-target snapshot file each tick
            var perTargetPath = Path.Combine(targetsFolder, $"{t.TargetId}.html");
            var perTargetHtml = BuildPerTargetHtml(
                displayName,
                instanceId,
                tzLabel,
                tz,
                t.Url,
                finalUrl,
                stateText,
                sinceUtc,
                lastCheckUtc,
                lastSummary,
                histList);

            await AtomicWriteUtf8Async(perTargetPath, perTargetHtml, ct);
        }

        sb.AppendLine("</tbody></table>");
        sb.AppendLine("</body></html>");

        var finalPath = Path.Combine(outputFolder, $"{instanceId}.html");
        await AtomicWriteUtf8Async(finalPath, sb.ToString(), ct);
    }

    private static string BuildPerTargetHtml(
        string displayName,
        string instanceId,
        string tzLabel,
        TimeZoneInfo tz,
        string url,
        string finalUrl,
        string stateText,
        DateTime? sinceUtc,
        DateTime? lastCheckUtc,
        string lastSummary,
        List<WebsiteMonitor.Storage.Models.Check>? histList)
    {
        var sb = new StringBuilder();
        sb.AppendLine("<!doctype html>");
        sb.AppendLine("<html><head><meta charset=\"utf-8\"/>");
        sb.AppendLine($"<title>WebsiteMonitor - {Html(displayName)} ({Html(instanceId)})</title>");
        sb.AppendLine("<style>");
        sb.AppendLine("body{font-family:Calibri,Segoe UI,Arial,sans-serif;margin:16px;background:#111;color:#eee;}");
        sb.AppendLine("h1{margin:0 0 6px 0;font-size:18px;}");
        sb.AppendLine(".meta{color:#bbb;margin:0 0 12px 0;font-size:12px;}");
        sb.AppendLine("a{color:#ddd;}");
        sb.AppendLine("table{border-collapse:collapse;width:100%;}");
        sb.AppendLine("th,td{border:1px solid #333;padding:8px;vertical-align:top;}");
        sb.AppendLine("th{background:#1b1b1b;text-align:left;}");
        sb.AppendLine(".url2{color:#aaa;font-size:12px;margin-top:4px;}");
        sb.AppendLine(".hist{margin-top:10px;font-size:12px;color:#ddd;}");
        sb.AppendLine(".hist table{width:100%;}");
        sb.AppendLine(".hist th,.hist td{padding:4px 6px;}");
        sb.AppendLine("</style></head><body>");

        sb.AppendLine($"<h1>{Html(displayName)} ({Html(instanceId)})</h1>");
        sb.AppendLine($"<div class=\"meta\">{Html(url)}</div>");
        if (!string.IsNullOrWhiteSpace(finalUrl))
            sb.AppendLine($"<div class=\"meta url2\"><a href=\"{HtmlAttr(finalUrl)}\" target=\"_blank\" rel=\"noopener noreferrer\">{Html(finalUrl)}</a></div>");

        sb.AppendLine("<table>");
        sb.AppendLine("<thead><tr>");
        sb.AppendLine($"<th>State</th><th>Since ({Html(tzLabel)})</th><th>Last Check ({Html(tzLabel)})</th><th>Last Summary</th>");
        sb.AppendLine("</tr></thead><tbody>");

        sb.AppendLine("<tr>");
        sb.AppendLine($"<td>{Html(stateText)}</td>");
        sb.AppendLine($"<td>{(sinceUtc == null ? "" : Html(FmtLocal(sinceUtc.Value, tz)))}</td>");
        sb.AppendLine($"<td>{(lastCheckUtc == null ? "" : Html(FmtLocal(lastCheckUtc.Value, tz)))}</td>");
        sb.AppendLine($"<td>{Html(lastSummary)}</td>");
        sb.AppendLine("</tr>");

        sb.AppendLine("</tbody></table>");

        if (histList != null && histList.Count > 0)
        {
            sb.AppendLine("<div class=\"hist\"><strong>Recent checks</strong>");
            sb.AppendLine($"<table><thead><tr><th>{Html(tzLabel)}</th><th>Summary</th></tr></thead><tbody>");

            foreach (var c in histList)
            {
                sb.AppendLine("<tr>");
                sb.AppendLine($"<td>{Html(FmtLocal(c.TimestampUtc, tz))}</td>");
                sb.AppendLine($"<td>{Html(c.Summary ?? "")}</td>");
                sb.AppendLine("</tr>");
            }

            sb.AppendLine("</tbody></table></div>");
        }

        sb.AppendLine("</body></html>");
        return sb.ToString();
    }

    private static async Task AtomicWriteUtf8Async(string finalPath, string content, CancellationToken ct)
    {
        var dir = Path.GetDirectoryName(finalPath);
        if (!string.IsNullOrWhiteSpace(dir))
            Directory.CreateDirectory(dir);

        var tmpPath = finalPath + ".tmp";
        await File.WriteAllTextAsync(tmpPath, content, Encoding.UTF8, ct);
        File.Move(tmpPath, finalPath, true);
    }


    private static DateTime EnsureUtc(DateTime dt)
        => dt.Kind == DateTimeKind.Utc ? dt : DateTime.SpecifyKind(dt, DateTimeKind.Utc);

    private static bool IsInstancePaused(WebsiteMonitor.Storage.Models.Instance inst, DateTime nowUtc)
    {
        if (inst.IsPaused)
            return true;

        if (inst.PausedUntilUtc.HasValue)
        {
            var u = EnsureUtc(inst.PausedUntilUtc.Value);
            if (u > nowUtc)
                return true;
        }

        return false;
    }

    private const string SnapshotDateTimeFormat = "MM/dd/yyyy h:mm:ss tt";

    private static string FmtLocal(DateTime utc, TimeZoneInfo tz)
    {
        // SQLite/EF often comes back as Kind=Unspecified; force UTC semantics
        var asUtc = utc.Kind == DateTimeKind.Utc ? utc : DateTime.SpecifyKind(utc, DateTimeKind.Utc);
        var local = TimeZoneInfo.ConvertTimeFromUtc(asUtc, tz);
        return local.ToString(SnapshotDateTimeFormat, CultureInfo.InvariantCulture);
    }

    private static TimeZoneInfo ResolveTimeZone(string? timeZoneId, ILogger logger)
    {
        if (string.IsNullOrWhiteSpace(timeZoneId))
            return TimeZoneInfo.Local;

        var id = timeZoneId.Trim();

        // 1) Direct (works on Linux for IANA; on Windows for Windows IDs)
        try
        {
            return TimeZoneInfo.FindSystemTimeZoneById(id);
        }
        catch
        {
            // ignore and try TZConvert
        }

        // 2) Try TimeZoneConverter if present (reflection; no hard dependency)
        try
        {
            var t = Type.GetType("TimeZoneConverter.TZConvert, TimeZoneConverter", false);
            if (t != null)
            {
                var mi = t.GetMethod(
                    "GetTimeZoneInfo",
                    BindingFlags.Public | BindingFlags.Static,
                    null,
                    new[] { typeof(string) },
                    null);

                if (mi != null)
                {
                    var tz = mi.Invoke(null, new object?[] { id }) as TimeZoneInfo;
                    if (tz != null)
                        return tz;
                }
            }
        }
        catch
        {
            // ignore
        }

        logger.LogWarning("Could not resolve TimeZoneId='{TimeZoneId}'. Falling back to Local.", id);
        return TimeZoneInfo.Local;
    }

    private static string Html(string? s)
        => System.Net.WebUtility.HtmlEncode(s ?? "");

    private static string HtmlAttr(string? s)
        => System.Net.WebUtility.HtmlEncode(s ?? "");
}
